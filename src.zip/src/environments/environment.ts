export const environment = {
    production: false,
    supabaseUrl: 'https://xzyjphjzyvmwvjdymlly.supabase.co',
    supabaseKey: 'eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJpc3MiOiJzdXBhYmFzZSIsInJlZiI6Inh6eWpwaGp6eXZtd3ZqZHltbGx5Iiwicm9sZSI6ImFub24iLCJpYXQiOjE3NDU5NTI1OTIsImV4cCI6MjA2MTUyODU5Mn0.TBXucbgwDBd-1fWSPuFP5E6OwiAaOYsJFeMRqIBQsAY',
  };